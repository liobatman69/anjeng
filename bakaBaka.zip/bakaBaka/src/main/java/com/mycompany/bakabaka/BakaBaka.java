/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bakabaka;
import java.util.Scanner;

/**
 *
 * @author HYPE
 */
public class BakaBaka {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("NAMA PEMBELI:");
        String nama = input.nextLine();
        
        System.out.println("NAMA MAKANAN:");
        String makanan = input.nextLine();
        
        System.out.println("HARGA MAKANAN:");
        double harga = input.nextDouble();
        
        System.out.println("JUMLAH MAKANAN:");
        int jumlah = input.nextInt();
        input.nextLine();
        
        System.out.println("nama minuman:");
        String minuman = input.nextLine();
        
        System.out.println("harga minuman:");
        double harga_a = input.nextDouble();
        
        System.out.println("jumlah minuman:");
        int jumlah_a = input.nextInt();
        input.nextLine();
        
        System.out.println("uang yang dibayarkan");
        double uang = input.nextDouble();
        
        double total_harga_makanan = harga*jumlah;
        double total_harga_minuman = harga_a*jumlah_a;
        double kembalian = uang - (total_harga_makanan + total_harga_minuman);
        
        System.out.println("===========================");
        
        System.out.println("nama pembeli: " + nama);
        
        System.out.println("nama makanan: " + makanan);
        System.out.println("harga makanan: " + harga);
        System.out.println("jumlah makanan: " + jumlah);
        System.out.println("total harga makanan: " + total_harga_makanan);
        
        System.out.println("nama minuman: " + minuman);
        System.out.println("harga minuman: " + harga_a);
        System.out.println("jumlah makanan: " + jumlah_a);
        System.out.println("total harga minuman: " + total_harga_minuman);
                
        System.out.println("total pembelian: " + (total_harga_makanan + total_harga_minuman));
        System.out.println("uang yang dibayar: " + uang);
        System.out.println("kembalian: " + kembalian);
        
        System.out.println("===========================");
                
        
    }
}
